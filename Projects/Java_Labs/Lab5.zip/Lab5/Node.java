public class Node {
	public int id;
	public String value;
	public Node nextNode;
	public Node prevNode;

	public Node(int id, String value) {
		this.id = id;
		this.node = node;
	}

	public void setNext(Node node) {
		this.node = nextNode;
	}

	public void setPrevious(Node node) {
		this.node = prevNode;
	}

	public void setValue(String value) {
		this.value = value;
	}
}