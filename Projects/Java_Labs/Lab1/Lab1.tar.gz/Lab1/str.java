class Str {
	public static void main(String[] args) {
		String message2 = "Thing 1 and 2";
		String Message2 = "Thing 4 and 5";
		System.out.println('1');
		System.out.println(message2);

		char temp[] = {'T','h','i','n','g',' ','1',' ','a','n','d',' ','2'};
		String message1 = Message2;
		System.out.println('2');
		System.out.println(message1);

		System.out.println('3');
		System.out.println(message2);
		System.out.println("-----");

		System.out.println('4');
		System.out.println(message2);
		System.out.println("-----");
	}
}